import { Link } from 'react-router-dom';
import type { Product } from '../products';

interface ProductCardProps {
  product: Product;
}

import { Link } from 'react-router-dom';
import type { Product } from '../products';
import { motion } from 'framer-motion';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <motion.div whileHover={{ scale: 1.05, filter: 'brightness(1.1)' }}>
      <Link to={`/product/${product.id}`} className="bg-white rounded-lg shadow-md overflow-hidden group block">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-64 object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="p-4">
          <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
          <p className="text-gray-600 mt-1">BDT {product.price.toFixed(2)}</p>
          <div className="mt-4 w-full bg-gray-800 text-white py-2 rounded-md text-center group-hover:bg-gray-700 transition-colors duration-300">
            View Details
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

