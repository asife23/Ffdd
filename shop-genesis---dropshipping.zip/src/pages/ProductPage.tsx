import { motion } from 'framer-motion';
import { useParams } from 'react-router-dom';
import { products } from '../products';

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const product = products.find((p) => p.id === Number(id));

  if (!product) {
    return <div>Product not found</div>;
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <motion.img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-auto object-cover rounded-lg shadow-md"
            referrerPolicy="no-referrer"
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
          <p className="text-2xl text-gray-700 mt-2">BDT {product.price.toFixed(2)}</p>
          <p className="text-gray-600 mt-4">Category: {product.category}</p>
          <button className="mt-8 w-full bg-gray-800 text-white py-3 rounded-md hover:bg-gray-700 transition-colors duration-300">
            Add to Cart
          </button>
        </div>
      </div>
    </motion.div>
  );
}

