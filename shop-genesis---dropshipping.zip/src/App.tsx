/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Routes, Route, Link } from 'react-router-dom';
import HomePage from './pages/HomePage';
import ProductPage from './pages/ProductPage';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <Link to="/">
            <h1 className="text-2xl font-bold text-gray-900 font-serif" style={{ fontFamily: '"Playfair Display", serif' }}>Shop Genesis</h1>
          </Link>
          <nav className="space-x-4">
            <Link to="/" className="text-gray-600 hover:text-gray-900">Home</Link>
            {/* Add other links here */}
          </nav>
        </div>
      </header>

      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/product/:id" element={<ProductPage />} />
        </Routes>
      </main>

      <footer className="bg-white border-t">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 text-center text-gray-500">
          <p>&copy; 2024 Shop Genesis. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

